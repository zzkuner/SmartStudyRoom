/**
  ******************************************************************************
  * @file    usart.h
  * @brief   This file contains all the function prototypes for
  *          the usart.c file
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USART_H__
#define __USART_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;

/* USER CODE BEGIN Private defines */
#define REC_LENGTH  1
#define MAX_REC_LENGTH  1024
extern uint8_t rxMessage[16];
extern uint8_t Uart1ReceiveBuf[MAX_REC_LENGTH]; //UART1瀛樺偍鎺ユ敹鏁版嵁
extern uint8_t Uart1ReceiveFlag ;                  //UART1鎺ユ敹瀹屾垚鏍囧織
extern uint16_t  Uart1ReceiveCnt ;                   //UART1鎺ュ彈鏁版嵁璁℃暟
extern uint8_t Uart1Temp[REC_LENGTH] ;           //UART1鎺ユ敹鏁版嵁缂撳瓨

extern uint8_t Uart2ReceiveBuf[MAX_REC_LENGTH]; //UART2瀛樺偍鎺ユ敹鏁版嵁
extern uint8_t Uart2ReceiveFlag ;                  //UART2鎺ユ敹瀹屾垚鏍囧織
extern uint16_t  Uart2ReceiveCnt ;                   //UART2鎺ュ彈鏁版嵁璁℃暟
extern uint8_t Uart2Temp[REC_LENGTH] ;           //UART2鎺ユ敹鏁版嵁缂撳瓨
/* USER CODE END Private defines */

void MX_USART1_UART_Init(void);
void MX_USART2_UART_Init(void);

/* USER CODE BEGIN Prototypes */

/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
