/*
 * BC26.h
 *
 *  Created on: 2022年7月5日
 *      Author: yatao
 */

#ifndef INC_BC26_H_
#define INC_BC26_H_

#include "main.h"

#define UART_CB   1
#define TIM_CB    2


typedef enum
{
  AT_TEST,
  AT_CFUN,
  AT_CIMI,
  AT_CGATT,
  AT_CESQ,
  AT_CSQ,
  AT_QLWCLOSE,
  AT_QLWDEL,
  AT_QLWSERV,
  AT_CGSN,
  AT_QLWCONF,
  AT_QLWADDOBJ_UP,
  AT_QLWADDOBJ_DN,
  AT_QLWOPEN,
  AT_QLWCFG,
  CONNECTED,
}BC26_AT_State;


extern unsigned char BC26TimeOut;
extern unsigned char BC26InitOK;
void BC26SendData(unsigned char len,char *data);//上发数据

void BC26_AT_Init(unsigned char mode);
void BC26RecDataHandler(void);
void SendDataToBC26();

#endif /* INC_BC26_H_ */
