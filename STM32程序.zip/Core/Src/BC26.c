#include "BC26.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "stdio.h"
#include "string.h"

#define BC26_TIME1   3000   //默认重发时间，单位毫秒
#define BC26_TIME2   500    //默认两条指令时间间隔，单位毫秒

#define AUTO_IMEI    1      /*是否自动配置IMEI，
为1表示使用模组自身的IMEI作为平台的设备标识符，自动配置，适用于新的模组
为0表示使用以下数组中的字符串作为平台的设备标识符，适用于模组自身的IMEI被用过的情况*/
uint8_t BC26_IMEI[]="AT+QLWCONF=\"862657059389639\"\r\n";

uint8_t BC26TimeOut = 0;     //BC26未在规定时间内返回数据，超时标志
uint8_t BC26InitOK = 0;      //BC26初始化成功标志。置1代表连接到了云平台
uint8_t BC26State = AT_TEST;       //BC状态机标志位


extern TIM_HandleTypeDef htim15;
/**
  * @brief 设置定时器，在指定时间溢出
  * @param 溢出时间，单位毫秒
  * @note  不确定关闭定时器是否需要清零COUNTER，也不确定重复开启会不会出错所以先关后开。
  *         优化代码时可以做测试
  * @retval None
  */
void SetTimer(unsigned short ms)
{
  HAL_TIM_Base_Stop(&htim15);
  __HAL_TIM_SET_COUNTER(&htim15,0);
  __HAL_TIM_SET_AUTORELOAD(&htim15,ms);
  __HAL_TIM_CLEAR_FLAG(&htim15,TIM_FLAG_UPDATE);
  HAL_TIM_Base_Start_IT(&htim15);  //开启定时器中断前，清除标志位
}

/**
  * @brief 清除BC26缓存数组
  * @param None
  * @note  只要串口2收到数据并正确截断，就要清除缓冲，否则后续接收的数据不再从[0]开始
  * @retval None
  */
void CleanBC26Buffer()
{
  //HAL_UART_Transmit(&huart1,Uart2ReceiveBuf,Uart2ReceiveCnt,0xFFFF);    //发送接收到的数据
  printf("收到BC26的数据:%s\r\n",Uart2ReceiveBuf);
  for(int i = 0;i<Uart2ReceiveCnt;i++)
    Uart2ReceiveBuf[i] = 0;
  Uart2ReceiveCnt = 0;
  Uart2ReceiveFlag = 0;
}

/**
	* @brief 通过串口2向通信模组发送AT指令
  * @param 数组，长度
  * @note  None
  * @retval None
  */
static void send_AT_CMD(uint8_t *pData, uint16_t Size)
{
	//HAL_GPIO_TogglePin(LED2_GPIO_Port,LED2_Pin);
	printf("向BC26发送指令：%s",pData);
	HAL_UART_Transmit(&huart2,pData,Size,1000);
}


/**
  * @brief BC26初始化函数，成功运行后可以连接上华为云
  * @param 模式，表示由串口/定时器溢出  UART_CB/TIM_CB，调用此函数
  * @note
  * @retval None
  */
void BC26_AT_Init(uint8_t mode)
{
  switch(BC26State)
  {
    case AT_TEST:
    {
      if(mode == TIM_CB)   //如果定时器溢出，调用此函数，或者第一次调用
      {
        HAL_GPIO_WritePin(PWR_GPIO_Port, PWR_Pin, GPIO_PIN_SET);
        HAL_Delay(500);  //操作PWR引脚
        HAL_GPIO_WritePin(PWR_GPIO_Port, PWR_Pin, GPIO_PIN_RESET);
      	const char * tempbuf = "AT\r\n";        //用临时数组储存AT指令
        send_AT_CMD((uint8_t *)tempbuf,strlen(tempbuf));    //用strlen求出temp长度，避免发送无用内容
        SetTimer(BC26_TIME1);
      }
      else if(mode == UART_CB) //如果由BC26返回数据，调用此函数
      {
      	if(strstr((char *)Uart2ReceiveBuf, "AT")) //数据中包含AT
      	{
      		printf("BC26模组已连接！\n");
          BC26State = AT_CFUN;//迁移到下一个状态
          SetTimer(BC26_TIME2);//设置定时器，在指定时间后，会再次调用BC26_AT_Init函数
      	}
      	//未包含OK，不处理，等到BC26_TIME1的定时时间到，会再次调用函数的。
      	CleanBC26Buffer();     //清除串口2接收数组缓冲
      }
    }break;

    case AT_CFUN:
    {
      if(mode == TIM_CB)   //如果定时器溢出，调用此函数，或者第一次调用
      {
      	const char * tempbuf = "AT+CFUN=1\r\n";        //用临时数组储存AT指令
        send_AT_CMD((uint8_t *)tempbuf,strlen(tempbuf));    //用strlen求出temp长度，避免发送无用内容
        SetTimer(BC26_TIME1);
      }
      else if(mode == UART_CB) //如果由BC26返回数据，调用此函数
      {
      	if(strstr((char *)Uart2ReceiveBuf, "OK")) //数据中包含OK
      	{
          BC26State = AT_CIMI;//迁移到下一个状态
          SetTimer(BC26_TIME2);//设置定时器，在指定时间后，会再次调用BC26_AT_Init函数
      	}
      	//未包含OK，不处理，等到BC26_TIME1的定时时间到，会再次调用函数的。
      	CleanBC26Buffer();     //清除串口2接收数组缓冲
      }
    }break;

    case AT_CIMI:
		{
			if(mode == TIM_CB)   //如果定时器溢出，调用此函数，或者第一次调用
			{
				const char * tempbuf = "AT+CIMI\r\n";        //用临时数组储存AT指令
				send_AT_CMD((uint8_t *)tempbuf,strlen(tempbuf));    //用strlen求出temp长度，避免发送无用内容
				SetTimer(BC26_TIME1);
			}
			else if(mode == UART_CB) //如果由BC26返回数据，调用此函数
			{
				if(strstr((char *)Uart2ReceiveBuf, "460")) //CIMI多数以460开头
				{
					BC26State = AT_CGATT;//迁移到下一个状态
					SetTimer(BC26_TIME2);//设置定时器，在指定时间后，会再次调用BC26_AT_Init函数
				}
				//未包含OK，不处理，等到BC26_TIME1的定时时间到，会再次调用函数的。
				CleanBC26Buffer();     //清除串口2接收数组缓冲
			}
		}break;

    case AT_CGATT://PS域附着
		{
			if(mode == TIM_CB)   //如果定时器溢出，调用此函数，或者第一次调用
			{
				const char * tempbuf = "AT+CGATT=1\r\n";        //用临时数组储存AT指令
				send_AT_CMD((uint8_t *)tempbuf,strlen(tempbuf));    //用strlen求出temp长度，避免发送无用内容
				SetTimer(BC26_TIME1);
			}
			else if(mode == UART_CB) //如果由BC26返回数据，调用此函数
			{
				if(strstr((char *)Uart2ReceiveBuf, "OK")) //
				{
					BC26State = AT_CSQ;//迁移到下一个状态
					SetTimer(BC26_TIME2);//设置定时器，在指定时间后，会再次调用BC26_AT_Init函数
				}
				else
				{
					static uint8_t errorCnt1 = 0;
					if(++errorCnt1 > 3)
					{
						errorCnt1 = 0;
						BC26State = AT_CFUN;  //状态回退
						printf("PS域附着失败，可能卡欠费，正在尝试重新连接。\n");
					}
				}
				CleanBC26Buffer();     //清除串口2接收数组缓冲
			}
		}break;

    case AT_CSQ:
		{
			if(mode == TIM_CB)   //如果定时器溢出，调用此函数，或者第一次调用
			{
				const char * tempbuf = "AT+CSQ\r\n";        //用临时数组储存AT指令
				send_AT_CMD((uint8_t *)tempbuf,strlen(tempbuf));    //用strlen求出temp长度，避免发送无用内容
				SetTimer(BC26_TIME1);
			}
			else if(mode == UART_CB) //如果由BC26返回数据，调用此函数
			{
				if(strstr((char *)Uart2ReceiveBuf, "CSQ: 0,0")) //包含0,0，停机
				{
					printf("无信号，正在尝试重新连接。\n");
				}
				else
				{
					BC26State = AT_QLWCLOSE;//迁移到下一个状态
					SetTimer(BC26_TIME2);//设置定时器，在指定时间后，会再次调用BC26_AT_Init函数
				}
				//未包含OK，不处理，等到BC26_TIME1的定时时间到，会再次调用函数的。
				CleanBC26Buffer();     //清除串口2接收数组缓冲
			}
		}break;

    case AT_QLWCLOSE:
		{
			if(mode == TIM_CB)   //如果定时器溢出，调用此函数，或者第一次调用
			{
				const char * tempbuf="AT+QLWCLOSE\r\n";        //用临时数组储存AT指令
				send_AT_CMD((uint8_t *)tempbuf,strlen(tempbuf));    //用strlen求出temp长度，避免发送无用内容
				SetTimer(BC26_TIME1);
			}
			else if(mode == UART_CB) //如果由BC26返回数据，调用此函数
			{
				//这条命令不检查
				BC26State = AT_QLWDEL;//迁移到下一个状态
				SetTimer(BC26_TIME2);//设置定时器，在指定时间后，会再次调用BC26_AT_Init函数
				CleanBC26Buffer();     //清除串口2接收数组缓冲
			}
		}break;

    case AT_QLWDEL:
		{
			if(mode == TIM_CB)   //如果定时器溢出，调用此函数，或者第一次调用
			{
				const char * tempbuf ="AT+QLWDEL\r\n";       //用临时数组储存AT指令
				send_AT_CMD((uint8_t *)tempbuf,strlen(tempbuf));    //用strlen求出temp长度，避免发送无用内容
				SetTimer(BC26_TIME1);
			}
			else if(mode == UART_CB) //如果由BC26返回数据，调用此函数
			{
				//这条命令不检查
				BC26State = AT_QLWSERV;//迁移到下一个状态
				SetTimer(BC26_TIME2);//设置定时器，在指定时间后，会再次调用BC26_AT_Init函数
				CleanBC26Buffer();     //清除串口2接收数组缓冲
			}
		}break;

    case AT_QLWSERV:
		{
			if(mode == TIM_CB)   //如果定时器溢出，调用此函数，或者第一次调用
			{
				const char * tempbuf = "AT+QLWSERV=\"101.34.25.231\",1883\r\n";   //引号需要转义
				send_AT_CMD((uint8_t *)tempbuf,strlen(tempbuf));    //用strlen求出temp长度，避免发送无用内容
				SetTimer(BC26_TIME1);
			}
			else if(mode == UART_CB) //如果由BC26返回数据，调用此函数
			{
				if(strstr((char *)Uart2ReceiveBuf, "OK")) //
				{
#if AUTO_IMEI
					BC26State = AT_CGSN;//迁移到下一个状态
#else
					BC26State = AT_QLWCONF;//跳过AT_CGSN状态
#endif
					SetTimer(BC26_TIME2);//设置定时器，在指定时间后，会再次调用BC26_AT_Init函数
				}
				else
				{
					static uint8_t errorCnt2 = 0;
					if(++errorCnt2 > 3)
					{
						errorCnt2 = 0;
						BC26State = AT_CFUN;  //状态回退
						printf("配置IOT端口和平台地址失败，正在尝试重新连接。\n");
					}
				}
				CleanBC26Buffer();     //清除串口2接收数组缓冲
			}
		}break;

    case AT_CGSN:
		{
			if(mode == TIM_CB)   //如果定时器溢出，调用此函数，或者第一次调用
			{
				const char * tempbuf = "AT+CGSN=1\r\n";
				send_AT_CMD((uint8_t *)tempbuf,strlen(tempbuf));    //用strlen求出temp长度，避免发送无用内容
				SetTimer(BC26_TIME1);
			}
			else if(mode == UART_CB) //如果由BC26返回数据，调用此函数
			{
				char * strx = strstr((const char*)Uart2ReceiveBuf,(const char*)"+CGSN");
				if(strx != NULL)
				{
					for(char i=0;i<15;i++)
						BC26_IMEI[i+12]=strx[i+17];  //复制IMEI到BC26_IMEI数组
					printf("IMEI: %s\r\n",BC26_IMEI);
					BC26State = AT_QLWCONF;  //状态迁移
					SetTimer(2000);//设置定时器，在指定时间后，会再次调用BC26_AT_Init函数
				}
				//未包含OK，不处理，等到BC26_TIME1的定时时间到，会再次调用函数的。
				CleanBC26Buffer();     //清除串口2接收数组缓冲
			}
		}break;

    case AT_QLWCONF:
		{
			if(mode == TIM_CB)   //如果定时器溢出，调用此函数，或者第一次调用
			{
				send_AT_CMD((uint8_t *)BC26_IMEI,strlen(BC26_IMEI));    //用strlen求出temp长度，避免发送无用内容
				SetTimer(BC26_TIME1);
			}
			else if(mode == UART_CB) //如果由BC26返回数据，调用此函数
			{
				if(strstr((char *)Uart2ReceiveBuf, "OK"))
				{
					BC26State = AT_QLWADDOBJ_UP;  //状态迁移
					SetTimer(BC26_TIME2);//设置定时器，在指定时间后，会再次调用BC26_AT_Init函数
				}
				else
				{
					static uint8_t errorCnt3 = 0;
					if(++errorCnt3 > 3)
					{
						errorCnt3 = 0;
						BC26State = AT_CFUN;  //状态回退
						printf("配置IOT平台参数，正在尝试重新连接。\n");
					}
				}
				CleanBC26Buffer();     //清除串口2接收数组缓冲
			}
		}break;

    case AT_QLWADDOBJ_UP:
		{
			if(mode == TIM_CB)   //如果定时器溢出，调用此函数，或者第一次调用
			{
				const char * tempbuf = "AT+QLWADDOBJ=19,0,1,\"0\"\r\n";
				send_AT_CMD((uint8_t *)tempbuf,strlen(tempbuf));    //用strlen求出temp长度，避免发送无用内容
				SetTimer(BC26_TIME1);
			}
			else if(mode == UART_CB) //如果由BC26返回数据，调用此函数
			{
				if(strstr((char *)Uart2ReceiveBuf, "OK"))
				{
					BC26State = AT_QLWADDOBJ_DN;  //状态迁移
					SetTimer(BC26_TIME2);//设置定时器，在指定时间后，会再次调用BC26_AT_Init函数
				}
				//未包含OK，不处理，等到BC26_TIME1的定时时间到，会再次调用函数的。
				CleanBC26Buffer();     //清除串口2接收数组缓冲
			}
		}break;

    case AT_QLWADDOBJ_DN:
		{
			if(mode == TIM_CB)   //如果定时器溢出，调用此函数，或者第一次调用
			{
				const char * tempbuf = "AT+QLWADDOBJ=19,1,1,\"0\"\r\n";
				send_AT_CMD((uint8_t *)tempbuf,strlen(tempbuf));    //用strlen求出temp长度，避免发送无用内容
				SetTimer(BC26_TIME1);
			}
			else if(mode == UART_CB) //如果由BC26返回数据，调用此函数
			{
				if(strstr((char *)Uart2ReceiveBuf, "OK"))
				{
					BC26State = AT_QLWOPEN;  //状态迁移
					SetTimer(BC26_TIME2);//设置定时器，在指定时间后，会再次调用BC26_AT_Init函数
				}
				CleanBC26Buffer();     //清除串口2接收数组缓冲
			}
		}break;

    case AT_QLWOPEN:
		{
			if(mode == TIM_CB)   //如果定时器溢出，调用此函数，或者第一次调用
			{
				const char * tempbuf = "AT+QLWOPEN=0\r\n";
				send_AT_CMD((uint8_t *)tempbuf,strlen(tempbuf));    //用strlen求出temp长度，避免发送无用内容
				SetTimer(10000); //时间延长一些
			}
			else if(mode == UART_CB) //如果由BC26返回数据，调用此函数
			{
				if(strstr((char *)Uart2ReceiveBuf, "QLWOBSERVE"))
				{
					BC26State = AT_QLWCFG;  //状态迁移
					SetTimer(BC26_TIME2);//设置定时器，在指定时间后，会再次调用BC26_AT_Init函数
				}
				CleanBC26Buffer();     //清除串口2接收数组缓冲
			}
		}break;

    case AT_QLWCFG:
		{
			if(mode == TIM_CB)   //如果定时器溢出，调用此函数，或者第一次调用
			{
				const char * tempbuf = "AT+QLWCFG=\"dataformat\",1,1\r\n";
				send_AT_CMD((uint8_t *)tempbuf,strlen(tempbuf));    //用strlen求出temp长度，避免发送无用内容
				SetTimer(BC26_TIME1);
			}
			else if(mode == UART_CB) //如果由BC26返回数据，调用此函数
			{
				if(strstr((char *)Uart2ReceiveBuf, "OK"))
				{
					BC26State = CONNECTED;  //状态迁移
					SetTimer(BC26_TIME2);//设置定时器，在指定时间后，会再次调用BC26_AT_Init函数
				}
				CleanBC26Buffer();     //清除串口2接收数组缓冲
			}
		}break;

    case CONNECTED: BC26InitOK = 1;break;
			default:printf("未知的命令:%s\r\n",Uart2ReceiveBuf); break;
  }

}

void BC26SendData(unsigned char len,char *data)//上发数据
{
  char tempbuf[256],senddata[20];

  sprintf(senddata,"%s",data);  //将16进制的温湿度格式化打印到senddata数组中
  sprintf(tempbuf,"AT+QLWDATASEND=19,0,0,%d,%s\r\n",len,data);//除了字符33 len小于10适用
  send_AT_CMD((uint8_t *)tempbuf,14);
}

//正常工作以后，BC26处理串口收到的数据
void BC26RecDataHandler(void)
{
	printf("收到平台下发数据：\n");
  HAL_UART_Transmit(&huart1,Uart2ReceiveBuf,Uart2ReceiveCnt,0xFFFF);    //串口接收到的数据
  char * strx;
  strx=strstr((const char*)Uart2ReceiveBuf,(const char*)"+QLWDATARECV:");
  if(strx)  //暂时只处理云服务的下发命令
  {
    strx=strstr((const char*)strx,(const char*)",");//获取到第一个逗号
    strx=strstr((const char*)(strx+1),(const char*)",");//获取到第二个
    strx=strstr((const char*)(strx+1),(const char*)",");//获取到第三个
    strx=strstr((const char*)(strx+1),(const char*)",");//获取到四个
    //数据的格式一般为+QLWDATARECV: 19,1,0,1,01  处理后get strx is:  ,01
    //printf("get strx is:%s",strx);
/*    if(strx[2]=='1')//表明开灯
    {
      HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, LED_ON);
      printf("LED2 ON\r\n");
    }
    else if (strx[2]=='0')//表明关灯
    {
      HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, LED_OFF);
      printf("LED2 OFF\r\n");
    }*/
  }
  for(int i = 0;i<Uart2ReceiveCnt;i++)
    Uart2ReceiveBuf[i] = 0;
  Uart2ReceiveCnt = 0;
  Uart2ReceiveFlag = 0;
}

//串口1收到的数据，透传BC26
void SendDataToBC26()
{
  HAL_UART_Transmit(&huart2,Uart1ReceiveBuf,Uart1ReceiveCnt,0xffff);
  for(int i = 0;i<Uart1ReceiveCnt;i++)
    Uart1ReceiveBuf[i] = 0;
  Uart1ReceiveCnt = 0;
  Uart1ReceiveFlag = 0;
}
