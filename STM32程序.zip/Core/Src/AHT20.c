#include "AHT20.h"
extern txMessage[];
extern ct[];
uint8_t AHT20_Read_Status(void)//读取AHT10的状态寄存器
{
    uint8_t Byte_first;
    Sensors_I2C_ReadRegister(AHT20_SLAVE_ADDRESS, 0x00, 1,&Byte_first);

	return Byte_first;
}

uint8_t AHT20_Read_Cal_Enable(void)
{
    uint8_t val = 0;//ret = 0,

    val = AHT20_Read_Status();
    if((val & 0x68) == 0x08)  //判断NOR模式和校准输出是否有效
        return 1;
    else
        return 0;
}

void AHT20_Read_CTdata(uint32_t *ct) //读取AHT10的温度和湿度数据
{
    uint32_t RetuData = 0;
	uint16_t cnt = 0;
    uint8_t Data[10];
    uint8_t tmp[10];

    tmp[0] = 0x33;
    tmp[1] = 0x00;
	Sensors_I2C_WriteRegister(AHT20_SLAVE_ADDRESS,StartTest, 2, tmp);  //P0 口中断不使能
	HAL_Delay(80);//等待80ms

    cnt = 0;
	while(((AHT20_Read_Status()&0x80) == 0x80))//等待忙状态结束
	{
        HAL_Delay(1);
        if(cnt++ >= 100)
        {
            break;
        }
	}

    Sensors_I2C_ReadRegister(AHT20_SLAVE_ADDRESS, 0x00, 7,Data);

	RetuData = 0;
  RetuData = (RetuData|Data[1]) << 8;
	RetuData = (RetuData|Data[2]) << 8;
	RetuData = (RetuData|Data[3]);
	RetuData = RetuData >> 4;
	ct[0] = RetuData;

    RetuData = 0;
	RetuData = (RetuData|Data[3]) << 8;
	RetuData = (RetuData|Data[4]) << 8;
	RetuData = (RetuData|Data[5]);
	RetuData = RetuData&0xfffff;
	ct[1] = RetuData;
}

uint8_t count;
uint8_t AHT20_Init(void)
{
    uint8_t tmp[10];

    HAL_Delay(40);

    tmp[0] = 0x08;
    tmp[1] = 0x00;
	  Sensors_I2C_WriteRegister(AHT20_SLAVE_ADDRESS,INIT, 2, tmp);  //P0 口中断不使能

    HAL_Delay(500);
    count = 0;

    while(AHT20_Read_Cal_Enable() == 0)//需要等待状态字status的Bit[3]=1时才去读数据。如果Bit[3]不等于1 ，发软件复位0xBA给AHT10，再重新初始化AHT10，直至Bit[3]=1
    {
        Sensors_I2C_WriteRegister(AHT20_SLAVE_ADDRESS,SoftReset, 0, tmp);
        HAL_Delay(200);

        Sensors_I2C_WriteRegister(AHT20_SLAVE_ADDRESS,INIT, 2, tmp);

        count++;
        if(count >= 10)
            return 0;
        HAL_Delay(500);
    }
    return 1;
}

//AHT20周期性汇报消息
void AHT20ReportData()
{
  //uint32_t CT_data[2];
  char senddata[7]="001234\0";//温湿度上报数据，地址0x00，温度0x12=18,湿度0x34=52
  //char payload[100];
  unsigned int temp,humi;
  
 // AHT20_Read_CTdata(CT_data);  //读取温度和湿度
  humi = ct[0] * 1000 / 1024 / 1024;  //计算得到湿度值（放大了10倍,如果c1=523，表示现在湿度为52.3%）
  temp = ct[1] * 200 *10 / 1024 / 1024 - 500;//计算得到温度值（放大了10倍，如果t1=245，表示现在温度为24.5℃）
  temp/=10;//实际数据要小10倍
  humi/=10;//实际数据要小10倍
  printf("获取温度%d,湿度%d\r\n",temp,humi);  //打印获取的温湿度
  txMessage[5] = ct[0];
  txMessage[6] = 0x0;
  txMessage[7] = ct[1];
  //TODO 这个计算温度与湿度的过程太复杂，可以优化
  //printf("printf temp is %d,hum is %d\r\n",temp,humi);  //打印获取的温湿度
  //温湿度的格式化打印，上传数据的格式很奇怪，用16进制表示数字，但是每个数字又要转为ASCII发送
  //如温度27=0x1B 然后发送"1B"

 // char tempstr[5]="0000\0";//手动添加\0  避免不正确截断
  //sprintf(tempstr,"%x%x",temp,humi); //将温湿度按照16进制格式化打印
  //sprintf(senddata,"00%s",tempstr);  //将16进制的温湿度格式化打印到senddata数组中

  BC26SendData(14,txMessage);//发数据到平台端
}
