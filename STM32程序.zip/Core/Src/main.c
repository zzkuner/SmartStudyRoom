/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "RC522.h"
#include "stdio.h"
#include "string.h"
#include "BC26.h"
#include "AHT20.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
 uint8_t txMessage[20] = {0};	//上行报文
 uint8_t rxMessage[16] = {0};	//下行报文
 uint32_t ct[2];
static uint16_t localSeatNum = 0x1;
uint8_t isOnSeat;
 uint8_t txFlag = 0,
		rxFlag= 0,
		updateDataFlag= 0,
		updateSeatFlag= 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

//读取卡号，做数据回填，成功读取到卡号就????? ,另一个是回调功能函数
uint8_t readCard(uint8_t *readUid,void(*funCallBack)(void))
{
	uint8_t Temp[5];
	if (PCD_Request(0x52, Temp) == 0)
	{
		if (PCD_Anticoll(readUid) == 0)
		{
			if(funCallBack!=NULL)
				funCallBack();
			return 0;
		}
	}
	return 1;
}

// 重定向printf start
//_write函數在syscalls.c中， 使用__weak定義???????? ????????以可以直接在其他文件中定義_write函數
__attribute__((weak)) int _write(int file, char *ptr, int len)
{
	 if(HAL_UART_Transmit(&huart1,ptr,len,0xffff) != HAL_OK)
	 {
		 Error_Handler();
	 }
}



/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

	uint8_t readUid[5];
	uint16_t rxSeatNum;
	uint8_t relayStatus, reserveStatus, seatPermission = 1, isOnSeat;

//	uint8_t UID[5]={0xFB,0x29,0x0B,0x0A};//自己的卡号，可以通过串口打印通过下面读取到的打印到上位机，再把那个读取的卡号填入数组
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  MX_TIM3_Init();
  MX_TIM6_Init();
  MX_TIM7_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_TIM15_Init();
  /* USER CODE BEGIN 2 */
  //sys_init();
  /*RS522初始??*/
   MFRC_Init();
   PCD_Reset();
   BC26_AT_Init(TIM_CB); //调用BC26初始化函数连接华为云
    while(!BC26InitOK)    //只要没有初始化完成，程序就在此循环
  	{
  		if(Uart2ReceiveFlag)
  		{
  			BC26_AT_Init(UART_CB);
  			Uart2ReceiveFlag = 0;
  		}
  		if(BC26TimeOut)
  		{
  			BC26_AT_Init(TIM_CB);
  			BC26TimeOut = 0;
  		}
  	}
    printf("BC26配置完毕，已成功连接云平台。\n");
    I2C_Bus_Init();
   printf("RC522 INIT FINISH\n");

	printf("SERIAL 1&2 IT ON\n");


	 I2C_Bus_Init();
	  if(AHT20_Init() == 0)
		{
	    while(1)
	    {
	      printf("AHT20传感器初始化错误\r\n");
	      HAL_Delay(300);
	    }
		}
	  while(AHT20_Read_Cal_Enable() == 0)//也不晓得这AHT20为啥要初始化2次
	    {
	      AHT20_Init();//如果为0再使能一次
	      HAL_Delay(30);
	    }

	  __HAL_TIM_CLEAR_FLAG(&htim7,TIM_FLAG_UPDATE);
	  HAL_TIM_Base_Start_IT(&htim7);
	  __HAL_TIM_CLEAR_FLAG(&htim3,TIM_FLAG_UPDATE);
	  HAL_TIM_Base_Start_IT(&htim3);

	  /* 请在BC26初始化完成以后，再开启周期汇报数据的定时器
	   * 否则，这些定时器给BC26发送数据，可能导致BC26初始化失败
	   */
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
      {
	  if(!readCard(readUid,NULL)){
	  printf("%x %x %x %x\n\r\n\r\n\r",readUid[0],readUid[1],readUid[2],readUid[3]);
	  updateSeatFlag= 1;
	}

	  if(rxFlag)
	  {
		  if (0xB5 == rxMessage[0] && 0x5B == rxMessage[7])
		  {
		  rxSeatNum = rxMessage[1];
		  rxSeatNum = rxSeatNum << 0x8;
		  rxSeatNum += rxMessage[2];
		  printf("rx seat get\n\r");

		  if(0x0 == rxSeatNum || localSeatNum == rxSeatNum)
		  {
			  if (0x0 == rxMessage[3])
				  {
				  	  reserveStatus = rxMessage[4];
				  	  HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, reserveStatus);
				  	  printf("led2 toggled\n\r");
				  }
			  else if (0x1 == rxMessage[3])
				  {
				  	  seatPermission = rxMessage[5];
				  	  printf("seat permission changed\n\r");
				  }
			  else if (0x2 == rxMessage[3])
				  {
				  	  relayStatus = rxMessage[6];
				  	  switch (relayStatus)
				  	  {
				  	  	  case 0x0:
				  	  		  HAL_GPIO_WritePin(RELAY1_GPIO_Port, RELAY1_Pin, 0);
				  	  		  HAL_GPIO_WritePin(RELAY2_GPIO_Port, RELAY2_Pin, 0);
				  	  		printf("relay toggled 00\n\r");
				  	  		  break;
				  	  	  case 0x1:
				  	  		  HAL_GPIO_WritePin(RELAY1_GPIO_Port, RELAY1_Pin, 1);
				  	  		  HAL_GPIO_WritePin(RELAY2_GPIO_Port, RELAY2_Pin, 0);
				  	  		printf("relay toggled 01\n\r");
				  	  		  break;
				  	  	  case 0x2:
				  	  		  HAL_GPIO_WritePin(RELAY1_GPIO_Port, RELAY1_Pin, 0);
				  	  		  HAL_GPIO_WritePin(RELAY2_GPIO_Port, RELAY2_Pin, 1);
				  	  		printf("relay toggled 10\n\r");
				  	  		  break;
				  	  	  case 0x3:
				  	  		  HAL_GPIO_WritePin(RELAY1_GPIO_Port, RELAY1_Pin, 1);
				  	  		  HAL_GPIO_WritePin(RELAY2_GPIO_Port, RELAY2_Pin, 1);
				  	  		printf("relay toggled 11\n\r");
				  	  		  break;

				  	  }
				  }
			  for(int i = 0 ;i<=7; i++)
			{
				  rxMessage[i] = 0x0;
			}
			  rxFlag = 0;
		  }


		  }

	  }

	  if(updateDataFlag)
	  {

		  AHT20_Read_CTdata(ct);
		  txMessage[3] = 0x1;
		  txMessage[4] = HAL_GPIO_ReadPin(IR_SENSOR_GPIO_Port, IR_SENSOR_Pin);

		  txFlag = 1;
		  updateDataFlag= 0;
	  }

	  if(updateSeatFlag)
	  {

		  txFlag = 1;
		  txMessage[3] = 0x0;
		  txMessage[9] = readUid[0];
		  txMessage[10] = readUid[1];
		  txMessage[11] = readUid[2];
		  txMessage[12] = readUid[3];
		  updateSeatFlag= 0;
	  }

	 if(txFlag)
	  {
		  txMessage[0] = 0xA5;
		  txMessage[1] = 0x0;
		  txMessage[2] = 0x1;
		  txMessage[13] = 0x5A;
		  AHT20ReportData();
		  txFlag = 0;


	  }

	  if(0x0 ==seatPermission && 0 == isOnSeat)
	  {
		  printf("illegal sitting");
		  for(int i = 0; i<2; i++)
		  {
			  HAL_GPIO_WritePin(BUZZ_GPIO_Port, BUZZ_Pin, 1);
			  HAL_Delay(120);
			  HAL_GPIO_WritePin(BUZZ_GPIO_Port, BUZZ_Pin, 0);
			  HAL_Delay(80);
		  }
		  HAL_GPIO_WritePin(BUZZ_GPIO_Port, BUZZ_Pin, 1);
		  HAL_Delay(120);
		  HAL_GPIO_WritePin(BUZZ_GPIO_Port, BUZZ_Pin, 0);
	  }




    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV1;
  RCC_OscInitStruct.PLL.PLLN = 16;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the peripherals clocks
  */
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1|RCC_PERIPHCLK_USART2;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */
  //if(htim==(&htim3))


  if(htim->Instance == TIM7)
  {
  	updateDataFlag = 1;
  }

  if(htim->Instance == TIM15)
  {
    BC26TimeOut = 1;
    rxFlag = 1;
    HAL_TIM_Base_Stop(&htim15);
  }



  /* USER CODE END Callback 0 */

  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
